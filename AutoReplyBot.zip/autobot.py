from telethon import TelegramClient, events
import asyncio
from datetime import datetime

api_id = 20322998  # আপনার API ID
api_hash = '1a65193ace0f6f795f05017441fab7df'  # আপনার API Hash

client = TelegramClient('session_name', api_id, api_hash)
last_messages = {}

@client.on(events.NewMessage(incoming=True))
async def handler(event):
    sender_id = event.sender_id
    now = datetime.now()
    last_messages[sender_id] = now

    await asyncio.sleep(10)  # ⏱ ১০ সেকেন্ড অপেক্ষা

    # যদি ওই ইউজারের মেসেজ টাইম এখনো same থাকে, মানে আপনি রিপ্লাই দেননি
    if last_messages.get(sender_id) == now:
        await event.reply("আমি এখন ব্যস্ত আছি। আপনি যা বলতে চান বিস্তারিত লিখে রাখুন, আমি পরে দেখে উত্তর দিব।")

client.start()
print("Auto Reply Bot চলছে...")
client.run_until_disconnected()
